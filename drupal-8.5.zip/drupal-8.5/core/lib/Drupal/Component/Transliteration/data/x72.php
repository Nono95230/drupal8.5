<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'he', 'lan', 'biao', 'rong', 'li', 'mo', 'bao', 'ruo', 'lu', 'la', 'ao', 'xun', 'kuang', 'shuo', 'liao', 'li',
  0x10 => 'lu', 'jue', 'liao', 'yan', 'xi', 'xie', 'long', 'ye', 'can', 'rang', 'yue', 'lan', 'cong', 'jue', 'chong', 'guan',
  0x20 => 'ju', 'che', 'mi', 'tang', 'lan', 'zhu', 'lan', 'ling', 'cuan', 'yu', 'zhao', 'zhao', 'pa', 'zheng', 'pao', 'cheng',
  0x30 => 'yuan', 'ai', 'wei', 'han', 'jue', 'jue', 'fu', 'ye', 'ba', 'die', 'ye', 'yao', 'zu', 'shuang', 'er', 'pan',
  0x40 => 'chuang', 'ke', 'zang', 'die', 'qiang', 'yong', 'qiang', 'pian', 'ban', 'pan', 'chao', 'jian', 'pai', 'du', 'chuang', 'yu',
  0x50 => 'zha', 'bian', 'die', 'bang', 'bo', 'chuang', 'you', 'you', 'du', 'ya', 'cheng', 'niu', 'niu', 'pin', 'jiu', 'mou',
  0x60 => 'ta', 'mu', 'lao', 'ren', 'mang', 'fang', 'mao', 'mu', 'gang', 'wu', 'yan', 'ge', 'bei', 'si', 'jian', 'gu',
  0x70 => 'you', 'ge', 'sheng', 'mu', 'di', 'qian', 'quan', 'quan', 'zi', 'te', 'xi', 'mang', 'keng', 'qian', 'wu', 'gu',
  0x80 => 'xi', 'li', 'li', 'pou', 'ji', 'gang', 'zhi', 'ben', 'quan', 'chun', 'du', 'ju', 'jia', 'jian', 'feng', 'pian',
  0x90 => 'ke', 'ju', 'kao', 'chu', 'xi', 'bei', 'luo', 'jie', 'ma', 'san', 'wei', 'mao', 'dun', 'tong', 'qiao', 'jiang',
  0xA0 => 'xi', 'li', 'du', 'lie', 'pai', 'piao', 'bo', 'xi', 'chou', 'wei', 'kui', 'chou', 'quan', 'quan', 'ba', 'fan',
  0xB0 => 'qiu', 'ji', 'cai', 'zhuo', 'an', 'ge', 'zhuang', 'guang', 'ma', 'you', 'kang', 'bo', 'hou', 'ya', 'yin', 'huan',
  0xC0 => 'zhuang', 'yun', 'kuang', 'niu', 'di', 'qing', 'zhong', 'mu', 'bei', 'pi', 'ju', 'yi', 'sheng', 'pao', 'xia', 'tuo',
  0xD0 => 'hu', 'ling', 'fei', 'pi', 'ni', 'yao', 'you', 'gou', 'xue', 'ju', 'dan', 'bo', 'ku', 'xian', 'ning', 'huan',
  0xE0 => 'hen', 'jiao', 'he', 'zhao', 'ji', 'xun', 'shan', 'ta', 'rong', 'shou', 'tong', 'lao', 'du', 'xia', 'shi', 'kuai',
  0xF0 => 'zheng', 'yu', 'sun', 'yu', 'bi', 'mang', 'xi', 'juan', 'li', 'xia', 'yin', 'suan', 'lang', 'bei', 'zhi', 'yan',
];
