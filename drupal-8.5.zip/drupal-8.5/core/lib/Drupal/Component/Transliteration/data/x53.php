<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'yun', 'wen', 'bi', 'gai', 'gai', 'bao', 'cong', 'yi', 'xiong', 'peng', 'ju', 'tao', 'ge', 'pu', 'e', 'pao',
  0x10 => 'fu', 'gong', 'da', 'jiu', 'qiong', 'bi', 'hua', 'bei', 'nao', 'shi', 'fang', 'jiu', 'yi', 'za', 'jiang', 'kang',
  0x20 => 'jiang', 'kuang', 'hu', 'xia', 'qu', 'bian', 'gui', 'qie', 'zang', 'kuang', 'fei', 'hu', 'yu', 'gui', 'kui', 'hui',
  0x30 => 'dan', 'gui', 'lian', 'lian', 'suan', 'du', 'jiu', 'jue', 'xi', 'pi', 'qu', 'yi', 'ke', 'yan', 'bian', 'ni',
  0x40 => 'qu', 'shi', 'xun', 'qian', 'nian', 'sa', 'zu', 'sheng', 'wu', 'hui', 'ban', 'shi', 'xi', 'wan', 'hua', 'xie',
  0x50 => 'wan', 'bei', 'zu', 'zhuo', 'xie', 'dan', 'mai', 'nan', 'dan', 'ji', 'bo', 'shuai', 'bo', 'kuang', 'bian', 'bu',
  0x60 => 'zhan', 'ka', 'lu', 'you', 'lu', 'xi', 'gua', 'wo', 'xie', 'jie', 'jie', 'wei', 'ang', 'qiong', 'zhi', 'mao',
  0x70 => 'yin', 'wei', 'shao', 'ji', 'que', 'luan', 'chi', 'juan', 'xie', 'xu', 'jin', 'que', 'wu', 'ji', 'e', 'qing',
  0x80 => 'xi', 'san', 'chang', 'wei', 'e', 'ting', 'li', 'zhe', 'han', 'li', 'ya', 'ya', 'yan', 'she', 'di', 'zha',
  0x90 => 'pang', 'ya', 'he', 'ya', 'zhi', 'ce', 'pang', 'ti', 'li', 'she', 'hou', 'ting', 'zui', 'cuo', 'fei', 'yuan',
  0xA0 => 'ce', 'yuan', 'xiang', 'yan', 'li', 'jue', 'sha', 'dian', 'chu', 'jiu', 'jin', 'ao', 'gui', 'yan', 'si', 'li',
  0xB0 => 'chang', 'lan', 'li', 'yan', 'yan', 'yuan', 'si', 'gong', 'lin', 'rou', 'qu', 'qu', 'er', 'lei', 'du', 'xian',
  0xC0 => 'zhuan', 'san', 'can', 'can', 'can', 'can', 'ai', 'dai', 'you', 'cha', 'ji', 'you', 'shuang', 'fan', 'shou', 'guai',
  0xD0 => 'ba', 'fa', 'ruo', 'shi', 'shu', 'zhuo', 'qu', 'shou', 'bian', 'xu', 'jia', 'pan', 'sou', 'gao', 'wei', 'sou',
  0xE0 => 'die', 'rui', 'cong', 'kou', 'gu', 'ju', 'ling', 'gua', 'dao', 'kou', 'zhi', 'jiao', 'zhao', 'ba', 'ding', 'ke',
  0xF0 => 'tai', 'chi', 'shi', 'you', 'qiu', 'po', 'ye', 'hao', 'si', 'tan', 'chi', 'le', 'diao', 'ji', 'liao', 'hong',
];
