Back up after : 

composer require drupal/admin_toolbar drupal/module_filter drupal/devel drupal/bootstrap 
composer require drupal/route_condition drupal/conditional_fields drupal/paragraphs 

den admin_toolbar admin_toolbar_tools module_filter devel kint
den route_condition conditional_fields paragraphs

enable the child theme in webmastering

default date : lundi

reglages custom dans views

d�sactivation des aggr�gations css, js et des caches(via settings.php,settings.local.php, servies.yml)